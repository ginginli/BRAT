class LanguageSwitcher { constructor() { console.log("����"); } init() { console.log("��ʼ��"); return Promise.resolve(); } }; window.LanguageSwitcher = LanguageSwitcher;
